## bing-search-dotnet Changelog

<a name="1.0.0"></a>
# 1.0.0 (2018-04-24)

*Features*
* Initial release with VisualSearch samples
