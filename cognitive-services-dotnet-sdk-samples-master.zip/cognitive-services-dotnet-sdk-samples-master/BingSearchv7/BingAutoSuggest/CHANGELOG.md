## bing-search-dotnet Changelog

<a name="1.0.0"></a>
# 1.0.0 (2017-10-31)

*Features*
* Initial release with AutoSuggestSearch samples
