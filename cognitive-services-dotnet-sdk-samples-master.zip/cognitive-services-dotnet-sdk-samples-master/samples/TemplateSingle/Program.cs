﻿using System;

namespace Microsoft.Azure.CognitiveServices.Samples.TemplateSingle
{
    /// <summary>
    /// Other class.
    /// 
    /// Non-Sample class must not be public.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // Write any code in Main
            Sample.RunSample("$SERVICE_ENDPOINT", "$SERVICE_KEY");
        }
    }
}
