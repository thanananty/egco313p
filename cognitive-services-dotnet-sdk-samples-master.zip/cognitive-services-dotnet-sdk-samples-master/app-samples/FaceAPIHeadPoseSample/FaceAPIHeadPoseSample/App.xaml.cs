﻿using System.Windows;

namespace FaceAPIHeadPoseSample
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
