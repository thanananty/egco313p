Please use `[API Name] Brief description` as title.

## API Name (Kind)
`Face`, `TextAnalytics`, `ComputerVision`...

## Purpose
Describe the intention of the changes being proposed.
What problem does it solve or functionality does it add?

## Other Information
Add any other helpful information that may be needed here.