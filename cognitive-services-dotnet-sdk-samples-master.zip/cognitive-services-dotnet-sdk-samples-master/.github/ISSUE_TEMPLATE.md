Please use `[API Name] Brief description` as title.

## API Name (Kind)
`Face`, `TextAnalytics`, `ComputerVision`...

## Issue Description
...